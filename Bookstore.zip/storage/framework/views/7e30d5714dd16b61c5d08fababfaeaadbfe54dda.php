

<?php $__env->startSection('content'); ?>
<div class="container">
      <div id="success" style="display:none" class="col-md-8 text-center h3 p-4 bg-success text-light rounded">تمت عملية الشراء بنجاح</div>
      <?php if(session('message')): ?>
       <div class="col-md-8 text-center h3 p-4 bg-success text-light rounded">تمت عملية الشراء بنجاح </div> 
     <?php endif; ?>
      <div class="row justify-content-center">
         <div class="col-md-12">
            <div class="card">
                  <div class="card-header">عربة التسوق</div>
                  <div class="card-body">
                     <?php if($items->count()): ?>
                     <table class="table">
                        <thead class="thead-light">
                              <tr>
                                    <th scope="col">العنوان</th>
                                    <th scope="col">السعر</th>
                                    <th scope="col">الكمية</th>
                                    <th scope="col">السعر الكلي</th>
                                    <th scope="col"></th>   
                              </tr>
                        </thead>
                        <?php ($totalPrice = 0); ?>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php ($totalPrice += $item->price * $item->pivot->number_of_copies); ?>
                           <tbody>
                              <tr>
                                  <th scope="row"><?php echo e($item->title); ?></th>
                                  <td><?php echo e($item->price); ?> $</td>
                                  <td><?php echo e($item->pivot->number_of_copies); ?></td>
                                  <td><?php echo e($item->price * $item->pivot->number_of_copies); ?> $</td>
                                  <td>
                                      <form style="float:left; margin: auto 5px" method="post" action="<?php echo e(route('cart.remove_all', $item->id)); ?>">
                                          <?php echo csrf_field(); ?>
                                          <button class="btn btn-outline-danger btn-sm" type="submit">أزل الكل</button>
                                      </form>

                                      <form style="float:left; margin: auto 5px" method="post" action="<?php echo e(route('cart.remove_one', $item->id)); ?>">
                                          <?php echo csrf_field(); ?>
                                          <button class="btn btn-outline-warning btn-sm" type="submit">أزل واحدًا</button>
                                      </form>
                                  </td>
                              </tr>
                          </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </table>
                     <h4 class="mb-5">المجموع النهائي: <?php echo e($totalPrice); ?> $</h4>
                     <!-- Set up a container element for the button -->
                    <div class="d-inline-block" id="paypal-button-container"></div>
                    <a href="<?php echo e(route('credit.checkout')); ?>" class="d-inline-block mb-4 float-start btn bg-cart" style="text-decoration:none;">
                        <span>بطاقة ائتمانية</span>
                        <i class="fas fa-credit-card"></i>
                    </a>
                     <?php else: ?>
                     <div class="alert alert-info text-center">
                         لا يوجد كتب في العربة   
                     </div>
                     <?php endif; ?>
                  </div>
            </div>
         </div>
      </div>
</div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <!-- Replace "test" with your own sandbox Business account app client ID -->
    <script src="https://www.paypal.com/sdk/js?client-id=AVE5YM0LArvWriUl3d0Q4FdDUfiA3TqvrgJ6pCnnvfkum-j90kHazNU24gk7QF4v00wz0L_I8V_WnXPb&currency=USD"></script>

    <script>
      paypal.Buttons({
        // Sets up the transaction when a payment button is clicked
        createOrder: (data, actions) => {
            return fetch('<?php echo e(route("create.paypal.pay")); ?>', {
                method: 'POST',
                body:JSON.stringify({
                    'userId' : "<?php echo e(auth()->user()->id); ?>",
                })
            }).then(function(res) {
                return res.json();
            }).then(function(orderData) {
                return orderData.id;
            });
        },
        // Finalize the transaction after payer approval
        onApprove: (data, actions) => {
            return fetch('<?php echo e(route("exceute.paypal.pay")); ?>' , {
                method: 'POST',
                body :JSON.stringify({
                    orderId : data.orderID,
                    userId: "<?php echo e(auth()->user()->id); ?>",
                })
            }).then(function(res) {
                return res.json();
            }).then(function(orderData) {
                $('#success').slideDown(200);
                $('.card-body').slideUp(0);
            });
        }
      }).render('#paypal-button-container');
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Bookstore\resources\views/cart.blade.php ENDPATH**/ ?>