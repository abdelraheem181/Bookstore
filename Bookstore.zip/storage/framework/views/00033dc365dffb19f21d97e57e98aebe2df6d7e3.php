<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
        <span>جميع الحقوق محفوظة &copy; <?php echo e(date('Y')); ?></span>
        </div>
    </div>
</footer><?php /**PATH C:\wamp64\www\Bookstore\resources\views/theme/footer.blade.php ENDPATH**/ ?>