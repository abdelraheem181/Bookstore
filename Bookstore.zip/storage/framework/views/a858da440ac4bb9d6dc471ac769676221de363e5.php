

<?php $__env->startSection('head'); ?>
<link href="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('heading'); ?>
جميع المشتريات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <table id="books-table" class="table table-striped table-bordered text-right" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>المشتري</th>
                    <th>الكتاب</th>
                    <th>السعر</th>
                    <th>عدد النسخ</th>
                    <th>السعر الإجمالي</th>
                    <th>تاريخ الشراء</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $allBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->user::find($product->user_id)->name); ?></td>
                        <td><a href="<?php echo e(route('book.detials', $product->book_id)); ?>"><?php echo e($product->book::find($product->book_id)->title); ?></a></td>
                        <td><?php echo e($product->price); ?>$</td>
                        <td><?php echo e($product->number_of_copies); ?></td>
                        <td><?php echo e($product->price * $product->number_of_copies); ?>$</td>
                        <td><?php echo e($product->created_at->diffForHumans()); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#books-table').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Arabic.json"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Bookstore\resources\views/admins/books/allProduct.blade.php ENDPATH**/ ?>