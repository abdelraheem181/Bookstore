

<?php $__env->startSection('content'); ?>
<div class="container">
      <div class="row justify-content-center">
            <div class="col-md-8">
                  <div class="card">
                        <div class="card-header">تصنيفات الكتب</div>


                        <div class="card-body">
                              <div class="row-justify-content-center">
                                    <form action="<?php echo e(route('cotegories.search')); ?>" method="GET">
                                          <div class="row d-flex justify-content-center">
                                              <input type="text" class="col-3 mx-sm-3 mb-2" name="term" placeholder="ابحث عن تصنيف...">
                                              <button type="submit" class="col-1 btn btn-secondary bg-secondary mb-2">ابحث</button>
                                          </div>
                                      </form>
                              </div>

                              <hr>

                              <br>
                              <h1 class="my-3"><b> <?php echo e($title); ?></b></h1>
                              <?php if($categories->count()): ?>
                                <ul>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a style="color:grey" href="<?php echo e(route('categories.list', $category)); ?>">
                                          <li class="list-group-item">
                                              <?php echo e($category->name); ?> (<?php echo e($category->books->count()); ?>)
                                          </li>
                                      </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                              <?php else: ?>
                              <div class="alert alert-success" role="alert">
                                    <h4 class="alert-heading">Well done!</h4>
                                    <p>حاول مرة اخرى رجاء </p>
                                    <hr>
                                    <p class="mb-0">شكرا لك</p>
                                </div>
                              <?php endif; ?>

                        </div>
                  </div>
            </div>
      </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Bookstore\resources\views/categories/list.blade.php ENDPATH**/ ?>